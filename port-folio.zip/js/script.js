const myFunction = function () {
  document.getElementById("navi-toggle").checked = false;
};

const link = document.getElementsByClassName("navigation__item");

setTimeout(function () {
  console.log(link.length);

  for (let i = 0; i < link.length; i++) {
    link[i].addEventListener("click", myFunction);
  }
}, 1);
